package com.project.entity;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Id;

public class Driver {
	
	@Id //pk
	@Column(name = "driverno")
	private int driverno;
	
	@Column(name = "drivername")
	private String name;
	
	@Column(name = "driverpassword")
	private double driverpassword;

	public int getDriverno() {
		return driverno;
	}

	public void setDriverno(int driverno) {
		this.driverno = driverno;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getDriverpassword() {
		return driverpassword;
	}

	public void setDriverpassword(double driverpassword) {
		this.driverpassword = driverpassword;
	}
	
	
}
