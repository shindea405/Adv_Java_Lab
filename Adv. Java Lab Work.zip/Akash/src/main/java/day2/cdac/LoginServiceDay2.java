package day2.cdac;

public class LoginServiceDay2 {
	
	public boolean loginCheck(String username, String password) {
		if (username.equals("akash") && password.equals("1234"))
			return true;
		return false;
	}

}
