package com.cdac.components;

public class CarParts {

}
