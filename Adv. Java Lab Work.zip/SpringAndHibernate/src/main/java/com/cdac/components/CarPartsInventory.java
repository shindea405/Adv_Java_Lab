package com.cdac.components;

public interface CarPartsInventory {

}
